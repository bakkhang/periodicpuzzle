using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using JetBrains.Annotations;

public class Timer : MonoBehaviour
{


    [SerializeField] TextMeshProUGUI timertext;
    [SerializeField] float remainingTime;

   /* public GameObject Image;

    private void Awake()
    {
        //Image.SetActive(false);
    }*/


    void Update()
    {
        if (remainingTime > 0)

        {
            remainingTime -= Time.deltaTime;
        }
        else if (remainingTime < 0)
        {
            //Image.SetActive(true);
            remainingTime = 0;
            
        }
        
       

        int minutes = Mathf.FloorToInt(remainingTime / 60);
        int seconds = Mathf.FloorToInt(remainingTime % 60);
        timertext.text = string.Format("{0:00}:{1:00}", minutes, seconds);
    }
}


