using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MangaePuzzleGame : MonoBehaviour
{
    
    public Image piece;
    public Image placeHolder;
    float phWidth, phHeight;

    void Start()
    {
        createPlaceHolders();
        createPieces();
    }

     void shufflePieces()
        {
            int[] newArray = new int[50];
            for (int I = 0; I < 50; I++)
                newArray[I] = I;
            int tmp;
            for (int t = 0; t < 50; t++)
            {
                tmp = newArray[t];
                int r = Random.Range(tmp, 50);
                newArray[t] = newArray[r];
                newArray[r] = tmp;
            }
            for (int I = 0; I < 50; I++)
            {
                float row, nbRows, nbColumns, column;
                nbRows = 5;
                nbColumns = 10;
                row = (newArray[I]) % 10;
                column = (newArray[I]) / 10;
                Vector3 centerPosition = new Vector3();
                centerPosition = GameObject.Find("leftside").transform.position;
                var g = GameObject.Find("Piece" + (I + 1));
                Vector3 newPosition = new Vector3(centerPosition.x + phWidth * (row - nbRows / 2), centerPosition.y - phHeight * (column - nbColumns / 2), centerPosition.z);
                g.transform.position = newPosition;

            }
        }
    

    

    public void createPlaceHolders()
    {
        phWidth = 50; phHeight = 50;
        float nbRows, nbColumns;
        nbRows = 5;
        nbColumns = 10;
        for (int I = 0; I < 50; I++)
        {
            Vector3 centerPosition = new Vector3();
            centerPosition = GameObject.Find("rightSide").transform.position;
            float row, column;
            row = I % 10;
            column = I / 10;
            Vector3 phPosition = new Vector3(centerPosition.x + phWidth * (row - nbRows / 2), centerPosition.y - phHeight * (column - nbColumns / 2));
            Image ph = (Image)(Instantiate(placeHolder, phPosition, Quaternion.identity));
            ph.tag = "" + (I + 1);
            ph.name = "PH" + (I + 1);
            ph.transform.SetParent(GameObject.Find("Canvas").transform);
        }
    }

    public void createPieces()
    {
        phWidth = 50;
        phHeight = 50;
        float nbRows, nbColumns;
        nbRows = 5;
        nbColumns = 10;


        for (int I = 0; I < 50; I++)
        {
            Vector3 centerPosition = new Vector3();
            centerPosition = GameObject.Find("leftSide").transform.position;
            float row, column;
            row = I % 10;
            column = I / 10;
            Vector3 phPosition = new Vector3(centerPosition.x + phWidth * (row - nbRows / 2), centerPosition.y - phHeight * (column - nbColumns / 2), centerPosition.z);
            Image ph = (Image)(Instantiate(piece, phPosition, Quaternion.identity));
            ph.tag = "" + (I + 1);
            ph.name = "Piece" + (I + 1);
            ph.transform.SetParent(GameObject.Find("Canvas").transform);
            Sprite[] allSprites = Resources.LoadAll<Sprite>("table");
            Sprite s1 = allSprites[I];
            ph.GetComponent<Image>().sprite = s1;


        }
    }

    
}
