using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Scene : MonoBehaviour
{
    public void GoToTutorial()
    {
        SceneManager.LoadScene("Tutorial");
    }

    public void BackToIntro()
    {
        SceneManager.LoadScene(0);
    }

    public void Playgame()
    {
        SceneManager.LoadScene(2);
    }

    public void Highscore()
    {
        SceneManager.LoadScene(3);
    }
    
      
    
}
